const form = document.getElementById('form');
  function compilaForm(){ 
   
        const formData = new FormData(form);
        const nome = formData.get('name');
        const email = formData.get('email');
        const data = formData.get(`date`); 
        const ora = formData.get(`time`); 
        const messaggio = formData.get(`messaggio`); 
        const soddisfazione = formData.get('esperienza');
        const qualità = formData.get('qualità');
        const utile = formData.get(`utile`); 

        console.log(`Nome: ${nome}`);
        console.log(`Email: ${email}`);
        console.log(`Data: ${data}`); 
        console.log(`Ora: ${ora}`); 
        console.log(`Messaggio: ${messaggio}`);
        console.log(`Nome: ${soddisfazione}`);
        console.log(`Email: ${qualità}`);
        console.log(`Data: ${utile}`);   
        if(nome =="" || email=="" || data=="" || ora=="" || messaggio=="" || soddisfazione=="" || qualità=="" || utile==""){
            alert("alcuni dei dati inseriti sono mancanti.")
            return false;

        }
        alert("il form è stato inviato con successo")
        form.reset(); 
  }