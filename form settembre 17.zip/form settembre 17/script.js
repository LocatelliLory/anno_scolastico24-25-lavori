    const form = document.getElementById('form');
    const messaggioOutput = document.getElementById('message');

    form.addEventListener('submit', (event) => {
        event.preventDefault(); // Prevent the default form submission

        const formData = new FormData(form);
        const name = formData.get('fName');
        const email = formData.get('email');
        const dataFeedback = formData.get(`date`)
        const message = formData.get(message)

        console.log(`Nome: ${name}`);
        console.log(`Email: ${email}`);
        console.log(`Data: ${dataFeedback}`); 
        console.log(`Messaggio: ${message}`); 

        messaggioOutput.textContent = `il form è stato inviato`;

        form.reset();
    });