document.getElementById('dataForm').addEventListener('submit', function(event) {
    event.preventDefault(); 

    const nome = document.getElementById('nome').value;
    const cognome = document.getElementById('cognome').value;
    const email = document.getElementById('email').value;
    const dataNascita = document.getElementById('dataNascita').value;
    const telefono = document.getElementById('telefono').value;
    const paese = document.getElementById('paese').value;
    const provincia = document.getElementById('provincia').value;
    const table = document.getElementById('dataTable').getElementsByTagName('tbody')[0];
    const newRow = table.insertRow();

    newRow.insertCell(0).textContent = nome;
    newRow.insertCell(1).textContent = cognome;
    newRow.insertCell(2).textContent = email;
    newRow.insertCell(3).textContent = dataNascita;
    newRow.insertCell(4).textContent = telefono;
    newRow.insertCell(5).textContent = paese;
    newRow.insertCell(6).textContent = provincia;
});
