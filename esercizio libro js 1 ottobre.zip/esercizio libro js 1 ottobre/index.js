let libro={
    titolo: "Titolo bello", 
    autore: "nome autore", 
    genere: "nome genere", 
    annoPubblicazione: 2006, 
    descrizione : function(){
        console.log(this.titolo + " " + this.autore + " " + this.genere + " " + this.annoPubblicazione + " ")
    }, 

    font : function(descrizione, italic){
        descrizione.style.fontFamily = italic; 
    }, 

    isClassico : function (annoPubblicazione){
       let classico = 2024-this.annoPubblicazione >= 50 ? "Questo libro è un classico" : "Questo libro è recente"; 
       console.log(classico); 
    }, 
}

libro.descrizione; 
libro.font; 
libro.isClassico;   