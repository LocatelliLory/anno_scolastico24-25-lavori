const destinations = {
    roma: 150,
    parigi: 200,
    newyork: 300,
    tokyo: 400
};

document.getElementById('bookingForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const name = document.getElementById('name').value;
    const destination = document.getElementById('destination').value;
    const departureDate = document.getElementById('departureDate').value;
    const passengers = parseInt(document.getElementById('passengers').value);

    const destinationCost = destinations[destination];
    const totalCost = destinationCost * passengers;

    const summaryText = `
        Nome: ${name}<br>
        Destinazione: ${destination.charAt(0).toUpperCase() + destination.slice(1)}<br>
        Data di partenza: ${departureDate}<br>
        Numero di passeggeri: ${passengers}<br>
        Costo totale: €${totalCost}
    `;

    document.getElementById('summaryText').innerHTML = summaryText;
    document.getElementById('summary').classList.remove('hidden');
});

function clearSummary() {
    document.getElementById('summary').classList.add('hidden');
    document.getElementById('bookingForm').reset();
}
