let cart = [];

document.getElementById('userForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    alert(`Dati inviati: Nome - ${name}, Email - ${email}`);
});

function aggiungiCarrello(product, price) {
    cart.push({ product, price });
    displayCart();
}

function rimuoviDaCarrello(index) {
    cart.splice(index, 1);
    displayCart();
}

function displayCart() {
    const cartItems = document.getElementById('cartItems');
    const total = document.getElementById('total');
    cartItems.innerHTML = '';

    let sum = 0;

    cart.forEach((item, index) => {
        sum += item.price;
        cartItems.innerHTML += `
            <li>
                ${item.product} - €${item.price}
                <button class="btn btn-error" onclick="rimuoviDaCarrello(${index})">Rimuovi</button>
            </li>
        `;
    });

    total.textContent = `Totale: €${sum}`;
}

function checkout() {
    if (cart.length === 0) {
        alert('Il carrello è vuoto!');
        return;
    }
    const paymentMethod = prompt("Seleziona il metodo di pagamento (carta di credito/PayPal):");
    alert(`Hai scelto il pagamento con ${paymentMethod}.`);
}
