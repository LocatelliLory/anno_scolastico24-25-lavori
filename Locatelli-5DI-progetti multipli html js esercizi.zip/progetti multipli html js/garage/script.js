function updateTotal() {
    const checkboxes = document.querySelectorAll('.checkbox');
    let total = 0;

    checkboxes.forEach(checkbox => {
        if (checkbox.checked) {
            total += parseFloat(checkbox.dataset.costo);
        }
    });

    document.getElementById('totalCost').textContent = `€${total}`;
}
