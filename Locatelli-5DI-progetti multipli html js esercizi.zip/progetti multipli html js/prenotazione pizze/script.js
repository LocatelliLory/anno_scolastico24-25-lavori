document.getElementById('pizzaForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const pizzaType = document.getElementById('pizzaType');
    const selectedPizza = pizzaType.options[pizzaType.selectedIndex];
    const pizzaPrice = parseFloat(selectedPizza.getAttribute('data-price'));
    const quantity = parseInt(document.getElementById('quantity').value);

    let extraIngredientsTotal = 0;
    const extraIngredients = document.querySelectorAll('.checkbox:checked');
    
    extraIngredients.forEach((ingredient) => {
        extraIngredientsTotal += parseFloat(ingredient.value);
    });

    const totalCost = (pizzaPrice + extraIngredientsTotal) * quantity;

    const summaryText = `
        Tipo di Pizza: ${selectedPizza.text}<br>
        Ingredienti Extra: ${Array.from(extraIngredients).map(ing => ing.parentNode.textContent).join(', ') || 'Nessuno'}<br>
        Quantità: ${quantity}<br>
        Costo Totale: €${totalCost.toFixed(2)}
    `;

    document.getElementById('summaryText').innerHTML = summaryText;
    document.getElementById('summary').classList.remove('hidden');
});

function clearSummary() {
    document.getElementById('summary').classList.add('hidden');
    document.getElementById('pizzaForm').reset();
}
