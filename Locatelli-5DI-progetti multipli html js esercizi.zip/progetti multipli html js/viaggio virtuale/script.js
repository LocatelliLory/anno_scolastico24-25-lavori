const cities = {
    roma: {
        title: "Roma",
        image: "https://th.bing.com/th/id/OIP.eFRfpAq6QZOJ-PWjF2rYuQHaE8?rs=1&pid=ImgDetMain",
        description: "Roma è la capitale d'Italia, famosa per la sua storia millenaria, l'architettura e la cultura."
    },
    parigi: {
        title: "Parigi",
        image: "https://th.bing.com/th?id=OSK.HEROein7CkZd07V9iGR38U2HmrNF1y3sAqeg5-PvIrYD52s&w=312&h=200&c=15&rs=2&o=6&oif=webp&cb=13&pid=SANGAM",
        description: "Parigi, capitale della Francia, è conosciuta come la 'Città della Luce' ed è famosa per la Torre Eiffel."
    },
    newyork: {
        title: "New York",
        image: "https://blog.123milhas.com/wp-content/uploads/2022/09/o-que-fazer-em-nova-york-passeios-e-pontos-turisticos-conexao123-1.jpg",
        description: "New York è una delle città più iconiche degli Stati Uniti, famosa per la Statua della Libertà e Times Square."
    },
    tokyo: {
        title: "Tokyo",
        image: "https://upload.wikimedia.org/wikipedia/commons/7/70/Ginza_at_Night%2C_Tokyo.jpg",
        description: "Tokyo è la capitale del Giappone, famosa per la sua tecnologia, cultura pop e tradizioni antiche."
    },
    londra: {
        title: "Londra",
        image: "https://th.bing.com/th/id/R.7cde33aa0c3d115fcfeb149f1f391ac4?rik=LNEqCwH3kzqH2w&riu=http%3a%2f%2fwww.strettoweb.com%2fwp-content%2fuploads%2f2017%2f10%2fLondra.jpg&ehk=OZRM2R0D0J9HhGpgXt8AmTqhwOyKya1e7oOBDgwB%2bUU%3d&risl=&pid=ImgRaw&r=0",
        description: "Londra è la capitale del Regno Unito, celebre per i suoi monumenti storici come il Big Ben e il British Museum."
    },
    berlino: {
        title: "Berlino",
        image: "https://th.bing.com/th/id/R.1015c4ca688ea32a1a2ce971eb6209be?rik=ZowzJGUS9a3h%2fA&pid=ImgRaw&r=0",
        description: "Berlino è la capitale della Germania, conosciuta per la sua storia, cultura e arte contemporanea."
    }
};

function showCity(city) {
    const cityInfo = document.getElementById('cityInfo');
    const cityTitle = document.getElementById('cityTitle');
    const cityImage = document.getElementById('cityImage');
    const cityDescription = document.getElementById('cityDescription');

    cityTitle.textContent = cities[city].title;
    cityImage.src = cities[city].image;
    cityDescription.textContent = cities[city].description;

    cityInfo.classList.remove('hidden');
}